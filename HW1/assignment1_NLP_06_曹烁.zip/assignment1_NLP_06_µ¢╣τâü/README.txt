Question of the ipython:
when i developed in the ipython, the unicode issue blocked my way even though I tried to define the Chinese unicode or utf-8.
When I switched to the pycharm, there is no issue at all. To save time, I use the pycharm to get the final result. The result is attached as the pic: optional_chat_robot_result_screenshot.
